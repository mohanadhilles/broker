<?php

namespace Laravel\Nova\Contracts;

interface ListableField
{
    //
}
