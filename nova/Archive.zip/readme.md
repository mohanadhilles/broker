# Laravel Nova

- [Website](https://nova.laravel.com)
- [Documentation](https://nova.laravel.com/docs)
    - [Installation](https://nova.laravel.com/docs/2.0/installation.html)
    - [Updating Nova](https://nova.laravel.com/docs/2.0/installation.html#updating-nova)
- [Nova Packages](https://novapackages.com)
